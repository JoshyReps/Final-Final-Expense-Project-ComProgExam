package classes;

public enum FoodType {
    FOODS,DRINKS,DESSERTS;
}
